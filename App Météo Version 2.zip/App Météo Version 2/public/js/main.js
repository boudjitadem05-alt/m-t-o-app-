/* ========================================
   MAIN.JS - FICHIER PRINCIPAL
   Point d'entrée de l'application
   Gère tous les événements et interactions utilisateur
   
   Chaque opération (recherche, coordonnées, bbox, région)
   affiche ses résultats dans son propre conteneur
   Les résultats ne se mélangent pas entre les sections
   ======================================== */

// ---- IMPORTS ----

import { fetchWeather, searchCityByName, searchCitiesInRegion } from "./api.js";
/* fetchWeather : récupère la météo pour des coordonnées lat/lon
   searchCityByName : recherche les coordonnées d'une ville par son nom
   searchCitiesInRegion : recherche des villes dans une région (bonus) */

import { clearLoading, displayWeather, showLoading, displaySavedLocations } from "./ui.js";
/* showLoading : affiche le message de chargement dans un conteneur
   clearLoading : enlève le message de chargement d'un conteneur
   displayWeather : crée et affiche une carte météo dans un conteneur ciblé
   displaySavedLocations : affiche la liste des villes sauvegardées */

import { saveLocation, getSavedLocations, clearLocations, removeLocation } from "./storage.js";
/* saveLocation : enregistre une ville dans localStorage
   getSavedLocations : récupère toutes les villes enregistrées
   clearLocations : supprime toutes les villes
   removeLocation : supprime une ville par index */

import { applyFilters } from "./filters.js";
/* applyFilters : montre/cache les informations selon les checkboxes */

import { filterByBoundingBox, filterByRegion } from "./bbox.js";
/* filterByBoundingBox : filtre les villes par zone géographique
   filterByRegion : filtre les villes par nom de région/département */

import { validateBoundingBox } from "./utils.js";
/* validateBoundingBox : vérifie que les 4 champs de la bounding box sont valides */

/* ========================================
   FONCTION UTILITAIRE : OBTENIR LA GRILLE D'UNE SECTION
   Chaque section a un div .results-container avec un .results-grid dedans
   Cette fonction retourne le .results-grid et rend le conteneur visible
   ======================================== */

/* getResultsGrid
   Retourne l'élément .results-grid à l'intérieur d'un conteneur de résultats
   et rend le conteneur visible (display: block)
   containerId = l'id du div .results-container (ex: "search-results") */
function getResultsGrid(containerId) {
    const container = document.getElementById(containerId);
    /* On récupère le conteneur de résultats par son id */

    container.style.display = "block";
    /* On rend le conteneur visible
       Il était caché par défaut (style="display:none" dans le HTML) */

    return container.querySelector(".results-grid");
    /* On retourne la grille à l'intérieur du conteneur
       C'est dans cette grille qu'on ajoutera les cartes météo */
}

/* ========================================
   FONCTIONS UTILITAIRES LOCALES
   ======================================== */

/* refreshSavedList
   Rafraîchit l'affichage de la liste des villes sauvegardées */
function refreshSavedList() {
    const locations = getSavedLocations();
    displaySavedLocations(locations, handleClickSavedCity, handleDeleteSavedCity);
}

/* handleClickSavedCity
   Appelée quand l'utilisateur clique sur une ville sauvegardée
   Affiche la météo dans la section "saved-results"
   Les cartes précédentes RESTENT affichées (on ajoute à côté) */
async function handleClickSavedCity(loc) {
    /* On récupère la grille de résultats de la section "Villes sauvegardées" */
    const grid = getResultsGrid("saved-results");
    /* getResultsGrid rend aussi le conteneur visible automatiquement */

    showLoading(grid);
    /* On affiche le chargement dans cette grille spécifique */

    const data = await fetchWeather(loc.lat, loc.lon);

    clearLoading(grid);
    /* On enlève le chargement de cette grille */

    displayWeather(loc.name, data, grid);
    /* On affiche la carte dans la grille des villes sauvegardées
       Le 3ème paramètre "grid" indique OÙ ajouter la carte
       Les autres sections ne sont pas touchées */

    applyFilters();
}

/* handleDeleteSavedCity
   Supprime une ville du localStorage et rafraîchit la liste */
function handleDeleteSavedCity(index) {
    removeLocation(index);
    refreshSavedList();
}

/* ========================================
   INITIALISATION AU CHARGEMENT DE LA PAGE
   ======================================== */

document.addEventListener("DOMContentLoaded", async () => {
    /* DOMContentLoaded se déclenche quand le HTML est complètement chargé */

    /* ---- Affichage des villes sauvegardées ---- */
    refreshSavedList();

    /* ---- Chargement automatique de Blois ---- */
    /* Blois s'affiche dans sa propre section "default-results"
       C'est la météo par défaut comme demandé dans le sujet */
    const defaultGrid = document.getElementById("default-results");
    /* default-results n'a pas de .results-container car il est toujours visible */

    showLoading(defaultGrid);

    const bloisData = await fetchWeather(47.5861, 1.3359);
    /* 47.5861, 1.3359 sont les coordonnées de Blois */

    clearLoading(defaultGrid);
    displayWeather("Blois", bloisData, defaultGrid);
    /* On affiche Blois dans la section par défaut */

    applyFilters();

    /* ---- Événements pour les boutons X de fermeture des résultats ---- */
    /* Chaque section a un bouton X (close-results-btn) qui cache le conteneur entier */
    document.querySelectorAll(".close-results-btn").forEach(btn => {
        btn.addEventListener("click", () => {
            const targetId = btn.getAttribute("data-target");
            /* data-target contient l'id du conteneur à cacher
               ex: data-target="search-results" */

            const container = document.getElementById(targetId);
            container.style.display = "none";
            /* On cache le conteneur */

            const grid = container.querySelector(".results-grid");
            grid.innerHTML = "";
            /* On vide aussi les cartes à l'intérieur
               comme ça quand on recliquera, c'est propre */
        });
    });
});

/* ========================================
   ÉVÉNEMENT : RECHERCHE PAR NOM DE VILLE
   Les résultats s'affichent dans #search-results
   ======================================== */

document.getElementById("search-city-btn").addEventListener("click", async () => {
    const city = document.getElementById("city-search").value.trim();

    if (!city) {
        alert("Veuillez entrer un nom de ville.");
        return;
    }

    /* On récupère la grille de la section recherche */
    const grid = getResultsGrid("search-results");
    /* Le conteneur search-results devient visible */

    showLoading(grid);

    try {
        const results = await searchCityByName(city);

        if (results.length === 0) {
            clearLoading(grid);
            alert("Ville non trouvée.");
            return;
        }

        const lat = results[0].lat;
        const lon = results[0].lon;

        const data = await fetchWeather(lat, lon);

        clearLoading(grid);
        displayWeather(city, data, grid);
        /* La carte s'affiche dans la section recherche uniquement */

        saveLocation({ name: city, lat, lon });
        refreshSavedList();
        applyFilters();
    } catch (error) {
        clearLoading(grid);
        alert("Erreur lors de la recherche.");
        console.error("Erreur recherche ville :", error);
    }
});

/* Rechercher en appuyant sur Entrée */
document.getElementById("city-search").addEventListener("keypress", (e) => {
    if (e.key === "Enter") {
        document.getElementById("search-city-btn").click();
    }
});

/* ========================================
   ÉVÉNEMENT : AJOUT MANUEL PAR COORDONNÉES
   Les résultats s'affichent dans #coords-results
   ======================================== */

document.getElementById("add-location-btn").addEventListener("click", async () => {
    const lat = document.getElementById("latitude").value;
    const lon = document.getElementById("longitude").value;

    if (!lat || !lon) {
        alert("Veuillez entrer latitude et longitude.");
        return;
    }

    /* On récupère la grille de la section coordonnées */
    const grid = getResultsGrid("coords-results");

    showLoading(grid);

    try {
        const data = await fetchWeather(lat, lon);

        clearLoading(grid);

        const locationName = `Lieu (${parseFloat(lat).toFixed(2)}, ${parseFloat(lon).toFixed(2)})`;
        displayWeather(locationName, data, grid);
        /* La carte s'affiche dans la section coordonnées uniquement */

        saveLocation({ name: locationName, lat, lon });
        refreshSavedList();
        applyFilters();

        document.getElementById("latitude").value = "";
        document.getElementById("longitude").value = "";
    } catch (error) {
        clearLoading(grid);
        alert("Erreur lors de la récupération météo.");
        console.error("Erreur ajout coordonnées :", error);
    }
});

/* ========================================
   ÉVÉNEMENT : FILTRES (CHECKBOXES)
   ======================================== */

document.querySelectorAll("input[type=checkbox]").forEach(cb => {
    cb.addEventListener("change", applyFilters);
});

/* ========================================
   ÉVÉNEMENT : SUPPRIMER TOUTES LES VILLES
   ======================================== */

document.getElementById("clear-saved-btn").addEventListener("click", () => {
    if (confirm("Voulez-vous vraiment supprimer toutes les villes sauvegardées ?")) {
        clearLocations();
        refreshSavedList();
    }
});

/* ========================================
   ÉVÉNEMENT : BOUNDING BOX (FORMULAIRE)
   Les résultats s'affichent dans #bbox-results
   ======================================== */

document.getElementById("bbox-form").addEventListener("submit", async (e) => {
    e.preventDefault();

    const minLat = parseFloat(document.getElementById("min-lat").value);
    const maxLat = parseFloat(document.getElementById("max-lat").value);
    const minLon = parseFloat(document.getElementById("min-lon").value);
    const maxLon = parseFloat(document.getElementById("max-lon").value);

    const errorEl = document.getElementById("bbox-error");

    /* Validation côté client */
    const validation = validateBoundingBox(minLat, maxLat, minLon, maxLon);

    if (!validation.valid) {
        errorEl.textContent = validation.message;
        errorEl.style.display = "block";
        return;
    }

    errorEl.style.display = "none";

    const filteredLocations = filterByBoundingBox(minLat, maxLat, minLon, maxLon);

    if (filteredLocations.length === 0) {
        alert("Aucune ville sauvegardée dans cette zone.");
        return;
    }

    /* On récupère la grille de la section bounding box */
    const grid = getResultsGrid("bbox-results");
    /* On vide les résultats précédents de cette section */
    grid.innerHTML = "";

    showLoading(grid);

    for (const loc of filteredLocations) {
        const data = await fetchWeather(loc.lat, loc.lon);
        displayWeather(loc.name, data, grid);
        /* Chaque ville filtrée s'affiche dans la section bbox */
    }

    clearLoading(grid);
    applyFilters();
});

/* ========================================
   ÉVÉNEMENT : FILTRAGE PAR RÉGION/DÉPARTEMENT
   Les résultats s'affichent dans #region-results
   ======================================== */

document.getElementById("filter-region-btn").addEventListener("click", async () => {
    const regionName = document.getElementById("region-search").value.trim();

    if (!regionName) {
        alert("Veuillez entrer un nom de département ou de région.");
        return;
    }

    /* On récupère la grille de la section région */
    const grid = getResultsGrid("region-results");
    /* On vide les résultats précédents */
    grid.innerHTML = "";

    showLoading(grid);

    try {
        const filteredLocations = await filterByRegion(regionName);

        if (filteredLocations.length === 0) {
            clearLoading(grid);
            alert("Aucune ville sauvegardée dans cette région/département.");
            return;
        }

        for (const loc of filteredLocations) {
            const data = await fetchWeather(loc.lat, loc.lon);
            displayWeather(loc.name, data, grid);
            /* Chaque ville filtrée s'affiche dans la section région */
        }

        clearLoading(grid);
        applyFilters();
    } catch (error) {
        clearLoading(grid);
        alert("Erreur lors du filtrage par région.");
        console.error("Erreur filtrage région :", error);
    }
});

/* ========================================
   ÉVÉNEMENT : DÉCOUVRIR DES VILLES (BONUS)
   Les villes découvertes s'affichent dans #discover-results
   Le bouton "Météo" ouvre la carte dans la section région
   ======================================== */

document.getElementById("discover-btn").addEventListener("click", async () => {
    const regionName = document.getElementById("discover-region").value.trim();

    if (!regionName) {
        alert("Veuillez entrer un nom de région ou département.");
        return;
    }

    const resultsContainer = document.getElementById("discover-results");
    resultsContainer.innerHTML = '<p class="info-text">Recherche en cours...</p>';

    try {
        const cities = await searchCitiesInRegion(regionName);

        resultsContainer.innerHTML = "";

        if (cities.length === 0) {
            resultsContainer.innerHTML = '<p class="info-text">Aucune ville trouvée dans cette zone.</p>';
            return;
        }

        cities.forEach(city => {
            const item = document.createElement("div");
            item.classList.add("discover-item");

            const nameSpan = document.createElement("span");
            nameSpan.textContent = city.name;

            /* Bouton "Météo" : affiche la carte dans la section région */
            const meteoBtn = document.createElement("button");
            meteoBtn.textContent = "Météo";
            meteoBtn.classList.add("btn-small");
            meteoBtn.addEventListener("click", async () => {
                /* On utilise la grille de la section région pour la météo découverte */
                const grid = getResultsGrid("region-results");
                showLoading(grid);
                const data = await fetchWeather(city.lat, city.lon);
                clearLoading(grid);
                displayWeather(city.name, data, grid);
                applyFilters();
            });

            /* Bouton "Sauvegarder" */
            const saveBtn = document.createElement("button");
            saveBtn.textContent = "Sauvegarder";
            saveBtn.classList.add("btn-small", "btn-success");
            saveBtn.addEventListener("click", () => {
                const saved = saveLocation({ name: city.name, lat: city.lat, lon: city.lon });

                if (saved) {
                    refreshSavedList();
                    saveBtn.textContent = "Fait !";
                    saveBtn.disabled = true;
                } else {
                    saveBtn.textContent = "Déjà ajoutée";
                    saveBtn.disabled = true;
                }
            });

            item.appendChild(nameSpan);
            item.appendChild(meteoBtn);
            item.appendChild(saveBtn);
            resultsContainer.appendChild(item);
        });

    } catch (error) {
        resultsContainer.innerHTML = '<p class="info-text">Erreur lors de la recherche.</p>';
        console.error("Erreur découverte villes :", error);
    }
});
