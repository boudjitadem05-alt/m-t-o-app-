/* ========================================
   FILTRES D'AFFICHAGE
   Gère la visibilité des différentes informations météo
   ======================================== */

/* applyFilters
   Lit l'état de chaque checkbox et montre/cache les éléments correspondants
   Chaque type de donnée a une classe CSS spécifique (.temp, .wind, .precip, .minmax)
   On utilise style.display pour montrer ("block") ou cacher ("none") */
export function applyFilters() {
    /* On récupère l'état (coché ou non) de chaque checkbox */
    const showTemp = document.getElementById("filter-temp").checked;
    // checked retourne true si la case est cochée, false sinon

    const showWind = document.getElementById("filter-wind").checked;
    const showPrecip = document.getElementById("filter-precip").checked;
    const showMinMax = document.getElementById("filter-minmax").checked;

    /* Pour chaque type de donnée, on parcourt tous les éléments ayant cette classe
       et on change leur display selon l'état de la checkbox */

    /* Filtrage de la température */
    document.querySelectorAll(".temp").forEach(el => {
        el.style.display = showTemp ? "" : "none";
        /* "" (chaîne vide) remet le display par défaut de l'élément
           "none" cache l'élément complètement */
    });

    /* Filtrage du vent */
    document.querySelectorAll(".wind").forEach(el => {
        el.style.display = showWind ? "" : "none";
    });

    /* Filtrage des précipitations (nouveau filtre) */
    document.querySelectorAll(".precip").forEach(el => {
        el.style.display = showPrecip ? "" : "none";
    });

    /* Filtrage des min/max (nouveau filtre) */
    document.querySelectorAll(".minmax").forEach(el => {
        el.style.display = showMinMax ? "" : "none";
    });
}
