/* ========================================
   STOCKAGE LOCAL (localStorage)
   Gestion de la sauvegarde des villes
   ======================================== */

const STORAGE_KEY = "saved_locations";
/* On utilise une constante pour centraliser le nom de la clé localStorage
   Si on change le nom, on n'a qu'un seul endroit à modifier */

/* saveLocation
   Ajoute une nouvelle ville à la liste des villes sauvegardées
   Vérifie d'abord si la ville n'est pas déjà enregistrée (même lat/lon) */
export function saveLocation(location) {
    const locations = getSavedLocations();
    // on récupère les villes déjà enregistrées

    /* On vérifie si la ville existe déjà pour éviter les doublons
       On compare les coordonnées arrondies à 2 décimales */
    const existe = locations.some(loc =>
        parseFloat(loc.lat).toFixed(2) === parseFloat(location.lat).toFixed(2) &&
        parseFloat(loc.lon).toFixed(2) === parseFloat(location.lon).toFixed(2)
    );
    /* some() retourne true si au moins un élément du tableau satisfait la condition
       toFixed(2) arrondit à 2 décimales pour éviter les problèmes de précision */

    if (existe) {
        return false;
        // on retourne false pour indiquer que la ville existe déjà
    }

    locations.push(location);
    // on ajoute la nouvelle ville au tableau

    localStorage.setItem(STORAGE_KEY, JSON.stringify(locations));
    /* localStorage ne stocke que des chaînes de caractères
       JSON.stringify convertit le tableau en string pour le stockage */

    return true;
    // on retourne true pour indiquer que la sauvegarde a réussi
}

/* getSavedLocations
   Récupère toutes les villes sauvegardées dans localStorage
   Retourne un tableau vide si aucune ville n'est enregistrée */
export function getSavedLocations() {
    return JSON.parse(localStorage.getItem(STORAGE_KEY)) || [];
    /* JSON.parse reconvertit la string en tableau JavaScript
       || [] retourne un tableau vide si rien n'est stocké (null) */
}

/* clearLocations
   Supprime toutes les villes sauvegardées */
export function clearLocations() {
    localStorage.removeItem(STORAGE_KEY);
    // removeItem supprime complètement la clé du localStorage
}

/* removeLocation
   Supprime une ville spécifique par son index dans le tableau
   Utilisé quand l'utilisateur clique sur le X d'une ville sauvegardée */
export function removeLocation(index) {
    const locations = getSavedLocations();
    // on récupère le tableau actuel

    locations.splice(index, 1);
    /* splice(index, 1) supprime 1 élément à la position "index"
       ça modifie le tableau en place */

    localStorage.setItem(STORAGE_KEY, JSON.stringify(locations));
    // on re-sauvegarde le tableau mis à jour
}
