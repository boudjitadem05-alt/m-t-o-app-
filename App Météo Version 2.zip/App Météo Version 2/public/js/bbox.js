/* ========================================
   BBOX.JS - FILTRAGE GÉOGRAPHIQUE
   Filtre les villes sauvegardées par bounding box
   ou par département/région
   ======================================== */

import { getSavedLocations } from "./storage.js";
import { isInBoundingBox } from "./utils.js";

/* filterByBoundingBox
   Filtre les villes enregistrées pour ne garder que celles
   comprises dans la zone définie par minLat, maxLat, minLon, maxLon */
export function filterByBoundingBox(minLat, maxLat, minLon, maxLon) {
    const locations = getSavedLocations();
    /* On récupère toutes les villes enregistrées dans localStorage
       On filtre uniquement parmi les villes que l'utilisateur a ajoutées */

    return locations.filter(loc =>
        isInBoundingBox(
            parseFloat(loc.lat),
            parseFloat(loc.lon),
            minLat,
            maxLat,
            minLon,
            maxLon
        )
    );
    /* filter() crée un nouveau tableau avec seulement les éléments qui passent le test
       parseFloat convertit les coordonnées stockées en string vers des nombres */
}

/* filterByRegion
   Filtre les villes sauvegardées en utilisant la bounding box d'une région ou département
   Étape 1 : On cherche la bounding box de la région via Nominatim
   Étape 2 : On filtre les villes sauvegardées avec cette bounding box */
export async function filterByRegion(regionName) {
    /* On cherche la région sur Nominatim pour obtenir sa bounding box
       accept-language=fr : force les résultats en français
       countrycodes=fr : limite la recherche à la France pour éviter les régions homonymes */
    const url = `https://nominatim.openstreetmap.org/search?format=json`
        + `&q=${encodeURIComponent(regionName)}`
        + `&limit=1`
        + `&accept-language=fr`
        + `&countrycodes=fr`;
    /* encodeURIComponent encode les caractères spéciaux pour l'URL
       limit=1 car on ne veut que le premier résultat (le plus pertinent) */

    const response = await fetch(url);
    const results = await response.json();

    if (results.length === 0) {
        return [];
        /* Si la région n'est pas trouvée, on retourne un tableau vide */
    }

    /* Nominatim retourne une bounding box sous la forme [latMin, latMax, lonMin, lonMax] */
    const bbox = results[0].boundingbox;
    const minLat = parseFloat(bbox[0]);
    const maxLat = parseFloat(bbox[1]);
    const minLon = parseFloat(bbox[2]);
    const maxLon = parseFloat(bbox[3]);
    /* On convertit les strings en nombres avec parseFloat
       car Nominatim retourne des strings */

    /* On réutilise filterByBoundingBox pour filtrer les villes */
    return filterByBoundingBox(minLat, maxLat, minLon, maxLon);
    /* Comme ça, on ne duplique pas la logique de filtrage
       On réutilise la fonction déjà existante */
}
