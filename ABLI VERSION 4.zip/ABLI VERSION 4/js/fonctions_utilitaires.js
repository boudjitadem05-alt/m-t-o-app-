/*les fonction utilitaires:
sont les fonctions réutilisables pour vérifications et calculs */


/*isInBoundingBox : cette fonction :
   vérifie si une position (lat, lon) est comprise dans une bounding box
   et retourne true si la position est dans la zone, sinon false */
export function isInBoundingBox(lat, lon, minLat, maxLat, minLon, maxLon) {
    return lat >= minLat &&
           lat <= maxLat &&
           lon >= minLon &&
           lon <= maxLon;
    /*ici on compare simplement les coordonnées avec les bornes min/max
    et si toutes les conditions sont vraies alors la ville est dans la zone */
}

/* computeTrend : cette fonction :
   compare la température max d'aujourd'hui avec celle de demain
   pour indiquer si le temps s'améliore ou se dégrade
   et retourne un objet avec le texte et la classe CSS correspondante */
export function computeTrend(data) {
    /*ici on vérifie que les données daily existent et ont au moins 2 jours */
    if (!data || !data.daily || !data.daily.temperature_2m_max || data.daily.temperature_2m_max.length < 2) {
        return { text: "Données insuffisantes", cssClass: "trend-stable" };
        //pour la protection si les données sont incomplètes
    }

    const aujourdhui = data.daily.temperature_2m_max[0];
    //température max d'aujourd'hui (à l'index 0)
    const demain = data.daily.temperature_2m_max[1];
    //température max de demain (index 1)

    if (demain > aujourdhui) {
        return { text: "Amelioration", cssClass: "trend-positive" };
        //si demain est plus chaud alors le temps s'améliore
    }
    if (demain < aujourdhui) {
        return { text: "Deterioration", cssClass: "trend-negative" };
        //si demain est plus froid alors le temps se dégrade
    }
    return { text: "Stable", cssClass: "trend-stable" };
    //si pareil alors le temps est stable
}

/* computeMultiDayTrend : cette fonction :
   analyse la tendance sur plusieurs jours (pas juste demain)
   et compare le premier jour et le dernier jour pour une tendance globale */
export function computeMultiDayTrend(data) {
    if (!data || !data.daily || !data.daily.temperature_2m_max) {
        return { text: "Données insuffisantes", cssClass: "trend-stable" };
    }

    const temps = data.daily.temperature_2m_max;
    //tableau des températures max pour chaque jour

    const premier = temps[0];
    //température du premier jour
    const dernier = temps[temps.length - 1];
    //température du dernier jour disponible

    const difference = dernier - premier;
    //calcul de la différence entre le dernier et le premier jour

    if (difference > 2) {
        return { text: "Nette amelioration sur les prochains jours", cssClass: "trend-positive" };
        // si +2 degrés ou plus nette amélioration ( on voit la différence)
    }
    if (difference > 0) {
        return { text: "Legere amelioration sur les prochains jours", cssClass: "trend-positive" };
        //si entre 0 et 2 degrés de plus
    }
    if (difference < -2) {
        return { text: "Nette deterioration sur les prochains jours", cssClass: "trend-negative" };
        //si -2 degrés ou moins : nette détérioration
    }
    if (difference < 0) {
        return { text: "Legere deterioration sur les prochains jours", cssClass: "trend-negative" };
        //si entre 0 et -2 degrés
    }
    return { text: "Temps stable sur les prochains jours", cssClass: "trend-stable" };
    // si la différence est 0
}

/* formatDate : cette fonction :
   formate une date ISO (ex: "2026-03-18") en format lisible (ex: "Mer. 18 Mars")
   et utilise les noms de jours et mois en français*/
export function formatDate(dateString) {
    const jours = ["Dim", "Lun", "Mar", "Mer", "Jeu", "Ven", "Sam"];
    //tableau des abréviations des jours de la semaine

    const mois = ["Jan", "Fev", "Mars", "Avr", "Mai", "Juin", "Juil", "Aout", "Sep", "Oct", "Nov", "Dec"];
    // tableau des abréviations des mois

    const date = new Date(dateString);
    // on crée un objet Date à partir de la chaîne ISO

    const jour = jours[date.getDay()];
    // getDay() retourne le numéro du jour (0=dimanche, 1=lundi, etc...)
    const numero = date.getDate();
    // getDate() : retourne le numéro du jour dans le mois (1-31)
    const nomMois = mois[date.getMonth()];
    // getMonth(): retourne le numéro du mois (0=janvier, 1=février, etc...)

    return `${jour}. ${numero} ${nomMois}`;
    // on retourne le format "Lun. 16 Mars"
}

/* formatHour : cette fonction :
   formate une date-heure ISO (ex: "2026-03-18T14:26") en heure simple (ex:"14h26") */
export function formatHour(dateTimeString) {
    const date = new Date(dateTimeString);
    // on crée un objet Date à partir de la chaîne

    const heures = String(date.getHours()).padStart(2, "0");
    // getHours(): retourne l'heure (0-23) et padStart ajoute un 0 devant si nécessaire

    const minutes = String(date.getMinutes()).padStart(2, "0");
    //getMinutes() : retourne les minutes, padStart pour avoir toujours 2 chiffres

    return `${heures}h${minutes}`;
    //retourne "14h26" par exemple
}

/* getWeatherDescription : cette fonction :
   retourne une description textuelle simple à partir du code météo Open-Meteo
   et les codes sont définis par l'API Open-Meteo (WMO weather codes) */
export function getWeatherDescription(code) {
    /*ici on utilise un objet pour associer chaque code à une description
       car c'est plus simple et lisible qu'un switch ou case */
    const descriptions = {
        0: "Ciel degagé",
        1: "Peu nuageux",
        2: "Partiellement nuageux",
        3: "Couvert",
        45: "Brouillard",
        48: "Brouillard givrant",
        51: "Bruine legere",
        53: "Bruine moderee",
        55: "Bruine forte",
        61: "Pluie legere",
        63: "Pluie moderee",
        65: "Pluie forte",
        71: "Neige legere",
        73: "Neige moderee",
        75: "Neige forte",
        80: "Averses legeres",
        81: "Averses moderees",
        82: "Averses fortes",
        95: "Orage",
        96: "Orage avec grele",
        99: "Orage violent"
    };

    return descriptions[code] || "Inconnu";
    // si le code n'est pas dans l'objet alors on retourne "Inconnu"
}

/* getWeatherIcon : cette fonction :
   retourne une icône SVG simple en fonction du code météo Open-Meteo
   chaque code correspond à un type de météo (soleil, nuage, pluie, neige, orage)
   et on retourne du HTML SVG inline pour l'afficher directement dans la page */
export function getWeatherIcon(code) {
    /* on détermine le type de météo à partir du code WMO
       0 = ciel dégagé (soleil)
       1-3 = nuageux (nuage)
       45, 48 = brouillard (brouillard)
       51-55 = bruine (pluie légère)
       61-65 = pluie
       71-75 = neige
       80-82 = averses
       95-99 = orage */

    /* soleil - code 0 : ciel complètement dégagé */
    if (code === 0) {
        return `<svg class="weather-icon" viewBox="0 0 64 64" width="48" height="48">
            <!-- cercle jaune central = le soleil -->
            <circle cx="32" cy="32" r="12" fill="#f59e0b" />
            <!-- rayons du soleil : 8 lignes partant du centre vers l'extérieur -->
            <g stroke="#f59e0b" stroke-width="3" stroke-linecap="round">
                <line x1="32" y1="6" x2="32" y2="14" />
                <line x1="32" y1="50" x2="32" y2="58" />
                <line x1="6" y1="32" x2="14" y2="32" />
                <line x1="50" y1="32" x2="58" y2="32" />
                <line x1="13" y1="13" x2="19" y2="19" />
                <line x1="45" y1="45" x2="51" y2="51" />
                <line x1="51" y1="13" x2="45" y2="19" />
                <line x1="19" y1="45" x2="13" y2="51" />
            </g>
        </svg>`;
    }

    /* peu nuageux - code 1 : soleil avec un petit nuage */
    if (code === 1) {
        return `<svg class="weather-icon" viewBox="0 0 64 64" width="48" height="48">
            <!-- petit soleil en haut à droite -->
            <circle cx="44" cy="18" r="8" fill="#f59e0b" />
            <g stroke="#f59e0b" stroke-width="2" stroke-linecap="round">
                <line x1="44" y1="5" x2="44" y2="8" />
                <line x1="44" y1="28" x2="44" y2="31" />
                <line x1="31" y1="18" x2="34" y2="18" />
                <line x1="54" y1="18" x2="57" y2="18" />
            </g>
            <!-- nuage en bas à gauche -->
            <ellipse cx="26" cy="40" rx="16" ry="10" fill="#94a3b8" />
            <ellipse cx="20" cy="36" rx="10" ry="8" fill="#94a3b8" />
            <ellipse cx="34" cy="36" rx="10" ry="8" fill="#94a3b8" />
        </svg>`;
    }

    /* partiellement nuageux - code 2 : nuage plus gros avec soleil */
    if (code === 2) {
        return `<svg class="weather-icon" viewBox="0 0 64 64" width="48" height="48">
            <!-- soleil caché derrière le nuage -->
            <circle cx="44" cy="22" r="10" fill="#f59e0b" />
            <!-- nuage principal gris clair -->
            <ellipse cx="28" cy="38" rx="18" ry="11" fill="#cbd5e1" />
            <ellipse cx="20" cy="33" rx="12" ry="9" fill="#cbd5e1" />
            <ellipse cx="38" cy="33" rx="12" ry="9" fill="#cbd5e1" />
        </svg>`;
    }

    /* couvert - code 3 : nuage gris sans soleil */
    if (code === 3) {
        return `<svg class="weather-icon" viewBox="0 0 64 64" width="48" height="48">
            <!-- nuage gris foncé = ciel couvert -->
            <ellipse cx="32" cy="34" rx="20" ry="12" fill="#94a3b8" />
            <ellipse cx="22" cy="28" rx="14" ry="10" fill="#94a3b8" />
            <ellipse cx="42" cy="28" rx="14" ry="10" fill="#94a3b8" />
        </svg>`;
    }

    /* brouillard - codes 45, 48 : lignes horizontales grises */
    if (code === 45 || code === 48) {
        return `<svg class="weather-icon" viewBox="0 0 64 64" width="48" height="48">
            <!-- lignes horizontales = brouillard -->
            <g stroke="#94a3b8" stroke-width="4" stroke-linecap="round">
                <line x1="10" y1="22" x2="54" y2="22" />
                <line x1="14" y1="32" x2="50" y2="32" />
                <line x1="10" y1="42" x2="54" y2="42" />
            </g>
        </svg>`;
    }

    /* bruine ou pluie légère - codes 51, 53, 55, 61, 80 */
    if (code >= 51 && code <= 55 || code === 61 || code === 80) {
        return `<svg class="weather-icon" viewBox="0 0 64 64" width="48" height="48">
            <!-- nuage gris -->
            <ellipse cx="30" cy="24" rx="18" ry="10" fill="#94a3b8" />
            <ellipse cx="20" cy="20" rx="12" ry="8" fill="#94a3b8" />
            <ellipse cx="40" cy="20" rx="12" ry="8" fill="#94a3b8" />
            <!-- gouttes de pluie légères (petites lignes bleues) -->
            <g stroke="#3b82f6" stroke-width="2" stroke-linecap="round">
                <line x1="20" y1="36" x2="18" y2="44" />
                <line x1="32" y1="36" x2="30" y2="44" />
                <line x1="42" y1="36" x2="40" y2="44" />
            </g>
        </svg>`;
    }

    /* pluie modérée à forte - codes 63, 65, 81, 82 */
    if (code === 63 || code === 65 || code === 81 || code === 82) {
        return `<svg class="weather-icon" viewBox="0 0 64 64" width="48" height="48">
            <!-- nuage gris foncé -->
            <ellipse cx="30" cy="20" rx="18" ry="10" fill="#64748b" />
            <ellipse cx="20" cy="16" rx="12" ry="8" fill="#64748b" />
            <ellipse cx="40" cy="16" rx="12" ry="8" fill="#64748b" />
            <!-- gouttes de pluie fortes (lignes bleues plus longues et plus nombreuses) -->
            <g stroke="#2563eb" stroke-width="2.5" stroke-linecap="round">
                <line x1="16" y1="32" x2="12" y2="44" />
                <line x1="24" y1="34" x2="20" y2="46" />
                <line x1="32" y1="32" x2="28" y2="44" />
                <line x1="40" y1="34" x2="36" y2="46" />
                <line x1="48" y1="32" x2="44" y2="44" />
            </g>
        </svg>`;
    }

    /* neige - codes 71, 73, 75 */
    if (code >= 71 && code <= 75) {
        return `<svg class="weather-icon" viewBox="0 0 64 64" width="48" height="48">
            <!-- nuage gris clair -->
            <ellipse cx="30" cy="20" rx="18" ry="10" fill="#94a3b8" />
            <ellipse cx="20" cy="16" rx="12" ry="8" fill="#94a3b8" />
            <ellipse cx="40" cy="16" rx="12" ry="8" fill="#94a3b8" />
            <!-- flocons de neige (étoiles blanches/bleu clair) -->
            <text x="16" y="42" font-size="12" fill="#93c5fd">*</text>
            <text x="30" y="46" font-size="12" fill="#93c5fd">*</text>
            <text x="42" y="40" font-size="12" fill="#93c5fd">*</text>
            <text x="24" y="54" font-size="10" fill="#bfdbfe">*</text>
            <text x="38" y="54" font-size="10" fill="#bfdbfe">*</text>
        </svg>`;
    }

    /* orage - codes 95, 96, 99 */
    if (code >= 95) {
        return `<svg class="weather-icon" viewBox="0 0 64 64" width="48" height="48">
            <!-- nuage très foncé = orage -->
            <ellipse cx="30" cy="18" rx="18" ry="10" fill="#475569" />
            <ellipse cx="20" cy="14" rx="12" ry="8" fill="#475569" />
            <ellipse cx="40" cy="14" rx="12" ry="8" fill="#475569" />
            <!-- éclair jaune en forme de zigzag -->
            <polygon points="30,28 24,40 32,40 26,56 40,36 32,36 38,28" fill="#facc15" />
        </svg>`;
    }

    /* par défaut : un nuage gris simple si code inconnu */
    return `<svg class="weather-icon" viewBox="0 0 64 64" width="48" height="48">
        <ellipse cx="32" cy="34" rx="18" ry="10" fill="#94a3b8" />
        <ellipse cx="24" cy="28" rx="12" ry="8" fill="#94a3b8" />
        <ellipse cx="40" cy="28" rx="12" ry="8" fill="#94a3b8" />
    </svg>`;
}

/* validateBoundingBox : cette fonction :
   valide les 4 champs de la bounding box
   et retourne un objet {valid: boolean, message: string }
   pour indiquer si les valeurs sont correctes */
export function validateBoundingBox(minLat, maxLat, minLon, maxLon) {
    /*ici la vérification 1 : tous les champs doivent être des nombres */
    if (isNaN(minLat) || isNaN(maxLat) || isNaN(minLon) || isNaN(maxLon)) {
        return { valid: false, message: "Tous les champs doivent être remplis avec des nombres." };
    }

    /*la vérification 2 : les latitudes doivent être entre -90 et 90 */
    if (minLat < -90 || minLat > 90 || maxLat < -90 || maxLat > 90) {
        return { valid: false, message: "Les latitudes doivent être entre -90 et 90." };
    }

    /*la vérification 3 : les longitudes doivent être entre -180 et 180 */
    if (minLon < -180 || minLon > 180 || maxLon < -180 || maxLon > 180) {
        return { valid: false, message: "Les longitudes doivent être entre -180 et 180." };
    }

    /*vérification 4 : min doit être inférieur à max */
    if (minLat >= maxLat) {
        return { valid: false, message: "La latitude min doit être inférieure à la latitude max." };
    }
    if (minLon >= maxLon) {
        return { valid: false, message: "La longitude min doit être inférieure à la longitude max." };
    }

    return { valid: true, message: "" }; //ici donc tout est bon
}
