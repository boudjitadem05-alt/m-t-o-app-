// Base URL de l'API Open-Meteo
const BASE_URL = "https://api.open-meteo.com/v1/forecast";

/* fetchWeather (récupérer la météo complète)
   On récupère la météo pour des coordonnées données
   On demande : current_weather, hourly (température, précipitations, vent), 
   et daily (min, max, précipitations) pour les 7 prochains jours */
export async function fetchWeather(lat, lon) {
    /* On construit l'URL avec tous les paramètres nécessaires :
       - current_weather=true : pour la météo actuelle
       - hourly : température, précipitations et vent heure par heure
       - daily : min/max température et précipitations par jour
       - forecast_days=7 : prévisions sur 7 jours (pour la partie "prochains jours")
       - timezone=auto : pour que les heures correspondent au fuseau local */
    const url = `${BASE_URL}?latitude=${lat}&longitude=${lon}`
        + `&current_weather=true`
        + `&hourly=temperature_2m,precipitation,windspeed_10m`
        + `&daily=temperature_2m_max,temperature_2m_min,precipitation_sum,weathercode`
        + `&forecast_days=7`
        + `&timezone=auto`;

    try {
        const response = await fetch(url);
        // fait appel API de façon asynchrone

        if (!response.ok) throw new Error("Erreur API météo");
        // gestion d'erreur si l'API retourne un code d'erreur (ex: 400, 500)

        return await response.json();
        // Transformation de la réponse en objet JavaScript (JSON)
    } catch (error) {
        console.error("Erreur fetchWeather :", error);
        // affichage de l'erreur dans la console pour le débogage
        return null;
        // Retourne null si problème, pour que l'appelant puisse gérer
    }
}

/* searchCityByName
   Utilise Nominatim OpenStreetMap pour récupérer lat/lon à partir d'un nom de ville
   On limite à 5 résultats et on demande le format JSON
   accept-language=fr force les résultats en français (évite l'arabe ou autres langues) */
export async function searchCityByName(city) {
    const url = `https://nominatim.openstreetmap.org/search?format=json`
        + `&q=${encodeURIComponent(city)}`
        + `&limit=5`
        + `&accept-language=fr`;
    /* encodeURIComponent sert à encoder les caractères spéciaux (accents, espaces)
       pour que l'URL soit valide
       accept-language=fr : IMPORTANT - force Nominatim à retourner les noms en français
       sans ça, certaines villes apparaissent en arabe ou dans leur langue locale */

    const response = await fetch(url);
    return await response.json();
    // retourne un tableau de résultats avec lat, lon, display_name (en français)
}

/* reverseGeocode
   Géocodage inversé : récupère le nom d'un lieu à partir de ses coordonnées lat/lon
   Utilise Nominatim OpenStreetMap
   Retourne le nom de la ville/lieu ou les coordonnées formatées si non trouvé */
export async function reverseGeocode(lat, lon) {
    const url = `https://nominatim.openstreetmap.org/reverse?format=json`
        + `&lat=${lat}`
        + `&lon=${lon}`
        + `&accept-language=fr`
        + `&zoom=10`;
    /* zoom=10 : niveau de détail (10 = ville/village)
       accept-language=fr : pour avoir les noms en français */

    try {
        const response = await fetch(url);
        const data = await response.json();

        if (data && data.address) {
            /* On cherche le nom le plus pertinent dans l'ordre :
               city > town > village > municipality > county > state */
            const name = data.address.city 
                || data.address.town 
                || data.address.village 
                || data.address.municipality
                || data.address.county
                || data.address.state
                || data.name
                || `Lieu (${parseFloat(lat).toFixed(2)}, ${parseFloat(lon).toFixed(2)})`;
            
            return name;
        }
        
        return `Lieu (${parseFloat(lat).toFixed(2)}, ${parseFloat(lon).toFixed(2)})`;
    } catch (error) {
        console.error("Erreur reverseGeocode :", error);
        return `Lieu (${parseFloat(lat).toFixed(2)}, ${parseFloat(lon).toFixed(2)})`;
    }
}

/* searchCitiesInRegion
   Recherche des villes dans une région ou un département français
   Méthode améliorée :
   1) On cherche la bounding box de la région via Nominatim (avec accept-language=fr)
   2) On fait PLUSIEURS requêtes avec les noms de grandes villes françaises courantes
      dans la viewbox pour trouver de vraies villes (pas des résultats aléatoires)
   3) On dédoublonne et on vérifie que chaque ville est bien DANS la bounding box */
export async function searchCitiesInRegion(regionName) {
    /* Étape 1 : On cherche la zone (région/département) pour obtenir sa bounding box
       accept-language=fr pour avoir les noms en français
       countrycodes=fr pour limiter à la France */
    const regionUrl = `https://nominatim.openstreetmap.org/search?format=json`
        + `&q=${encodeURIComponent(regionName)}`
        + `&limit=1`
        + `&accept-language=fr`
        + `&countrycodes=fr`;
    const regionResponse = await fetch(regionUrl);
    const regionResults = await regionResponse.json();

    if (regionResults.length === 0) {
        return [];
        // si la région n'est pas trouvée, on retourne un tableau vide
    }

    /* On récupère la bounding box de la région
       boundingbox est un tableau [latMin, latMax, lonMin, lonMax] */
    const bbox = regionResults[0].boundingbox;
    const minLat = parseFloat(bbox[0]);
    const maxLat = parseFloat(bbox[1]);
    const minLon = parseFloat(bbox[2]);
    const maxLon = parseFloat(bbox[3]);
    // on convertit en nombres pour les comparaisons

    /* Étape 2 : On recherche des villes dans cette bounding box
       On utilise featuretype=city pour ne récupérer QUE des villes
       viewbox = lonMin, latMin, lonMax, latMax (format Nominatim)
       bounded=1 force à ne retourner que des résultats dans la viewbox
       countrycodes=fr limite à la France pour éviter les résultats étrangers
       accept-language=fr force les noms en français
       On fait la requête avec un q vide (*) pour avoir toutes les villes de la zone */
    const citiesUrl = `https://nominatim.openstreetmap.org/search?format=json`
        + `&q=${encodeURIComponent(regionName)}`
        + `&featuretype=city`
        + `&viewbox=${minLon},${minLat},${maxLon},${maxLat}`
        + `&bounded=1`
        + `&limit=30`
        + `&accept-language=fr`
        + `&countrycodes=fr`;

    const citiesResponse = await fetch(citiesUrl);
    const citiesResults = await citiesResponse.json();

    /* Étape 2b : On fait une 2ème requête avec "ville" comme mot-clé
       car Nominatim retourne parfois des résultats différents selon le mot-clé
       Ça permet de trouver plus de villes dans la zone */
    const citiesUrl2 = `https://nominatim.openstreetmap.org/search?format=json`
        + `&q=ville`
        + `&featuretype=city`
        + `&viewbox=${minLon},${minLat},${maxLon},${maxLat}`
        + `&bounded=1`
        + `&limit=30`
        + `&accept-language=fr`
        + `&countrycodes=fr`;

    /* On attend un petit délai entre les 2 requêtes Nominatim
       pour respecter la limite de 1 requête/seconde de l'API */
    await new Promise(resolve => setTimeout(resolve, 1100));
    // setTimeout crée un délai, on l'encapsule dans une Promise pour l'await

    const citiesResponse2 = await fetch(citiesUrl2);
    const citiesResults2 = await citiesResponse2.json();

    /* Étape 3 : On fusionne les 2 listes et on dédoublonne
       On utilise un Map avec la clé "lat,lon" arrondie pour éviter les doublons */
    const allResults = [...citiesResults, ...citiesResults2];
    // spread operator pour fusionner les 2 tableaux

    const uniqueMap = new Map();
    // Map pour stocker les villes uniques (clé = coordonnées arrondies)

    allResults.forEach(city => {
        const lat = parseFloat(city.lat);
        const lon = parseFloat(city.lon);

        /* Étape 4 : On vérifie que la ville est VRAIMENT dans la bounding box
           Certaines villes peuvent être retournées par Nominatim
           mais être légèrement en dehors de la zone */
        if (lat >= minLat && lat <= maxLat && lon >= minLon && lon <= maxLon) {
            /* On utilise les coordonnées arrondies comme clé pour dédoublonner
               toFixed(2) arrondit à 2 décimales */
            const key = `${lat.toFixed(2)},${lon.toFixed(2)}`;

            if (!uniqueMap.has(key)) {
                /* On extrait le nom en français depuis display_name
                   display_name est au format "Ville, Département, Région, France"
                   On prend juste le premier morceau (le nom de la ville) */
                const name = city.display_name.split(",")[0].trim();
                // trim() enlève les espaces en début et fin

                uniqueMap.set(key, { name, lat, lon });
                // on ajoute la ville dans le Map
            }
        }
    });

    /* On convertit le Map en tableau pour le retour */
    return Array.from(uniqueMap.values());
    // values() retourne les valeurs du Map, Array.from les met dans un tableau
}
